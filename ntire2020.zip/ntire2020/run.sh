python train_nitre.py  --train_phrase 2  --test_img data/test/ntire_test/ --test_gt data/test/ntire_test_gt/
