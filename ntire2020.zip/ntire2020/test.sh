python test_nitre.py --test_img data/test/nitre2019/ --test_gt data/test/nitre2019_gt/  
